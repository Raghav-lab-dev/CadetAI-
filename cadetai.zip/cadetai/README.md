# CadetAI 🎖️

AI-powered study assistant for school students (Classes 6–12) and NDA aspirants.

- **Frontend:** Next.js 15 (App Router) + TypeScript + Tailwind CSS
- **Backend:** FastAPI (Python 3.11+)
- **Database:** SQLite (swap to Postgres by changing `DATABASE_URL`)
- **Auth:** JWT email/password (bcrypt hashing)
- **AI:** Gemini (chat / explanations / summaries) + DeepSeek (quizzes / flashcards / planning)
- **Theme:** Military / cadet aesthetic, dark + light modes

---

## 1. Folder structure

```
cadetai/
├── backend/
│   ├── app/
│   │   ├── main.py              # FastAPI entry
│   │   ├── config.py            # env / settings
│   │   ├── database.py          # SQLAlchemy engine + session
│   │   ├── models.py            # SQLAlchemy models (all tables)
│   │   ├── schemas.py           # Pydantic schemas
│   │   ├── security.py          # password hashing + JWT
│   │   ├── deps.py              # current_user dependency
│   │   ├── ai/
│   │   │   ├── gemini.py        # Gemini client (chat/summary)
│   │   │   └── deepseek.py      # DeepSeek client (quiz/cards/plan)
│   │   ├── utils/
│   │   │   ├── extract.py       # PDF / DOCX / TXT extraction
│   │   │   └── ratelimit.py     # simple in-memory limiter
│   │   └── routes/
│   │       ├── auth.py          # /signup /login /me
│   │       ├── chat.py          # /chat (streaming)
│   │       ├── notes.py         # /upload-notes /generate-summary
│   │       ├── quiz.py          # /generate-quiz + submit
│   │       ├── flashcards.py    # /generate-flashcards
│   │       ├── planner.py       # /generate-study-plan
│   │       ├── nda.py           # /nda/* daily quiz, CA, SSB
│   │       ├── dashboard.py     # /dashboard
│   │       └── analytics.py     # /analytics + weak topics
│   ├── seed.py                  # sample data
│   ├── requirements.txt
│   ├── .env.example
│   └── Dockerfile
├── frontend/
│   ├── app/
│   │   ├── layout.tsx
│   │   ├── page.tsx             # marketing landing
│   │   ├── globals.css
│   │   ├── (auth)/
│   │   │   ├── login/page.tsx
│   │   │   └── signup/page.tsx
│   │   └── (app)/
│   │       ├── layout.tsx       # sidebar shell
│   │       ├── dashboard/page.tsx
│   │       ├── chat/page.tsx
│   │       ├── notes/page.tsx
│   │       ├── quiz/page.tsx
│   │       ├── flashcards/page.tsx
│   │       ├── planner/page.tsx
│   │       ├── nda/page.tsx
│   │       ├── analytics/page.tsx
│   │       └── profile/page.tsx
│   ├── components/
│   │   ├── Sidebar.tsx
│   │   ├── Topbar.tsx
│   │   ├── ThemeToggle.tsx
│   │   ├── ChatWindow.tsx
│   │   ├── Flashcard.tsx
│   │   ├── QuizCard.tsx
│   │   ├── StreakBadge.tsx
│   │   └── VoiceInput.tsx
│   ├── lib/
│   │   ├── api.ts               # fetch wrapper, JWT
│   │   ├── auth.ts              # client auth helpers
│   │   ├── i18n.ts              # EN / HI strings
│   │   └── tts.ts               # browser SpeechSynthesis
│   ├── tailwind.config.ts
│   ├── postcss.config.mjs
│   ├── next.config.mjs
│   ├── tsconfig.json
│   ├── package.json
│   └── .env.local.example
├── docker-compose.yml
├── DEPLOYMENT.md
└── README.md
```

---

## 2. Quick start (local)

### Prerequisites
- Python 3.11+
- Node.js 20+
- A Gemini API key  →  https://aistudio.google.com/apikey
- A DeepSeek API key →  https://platform.deepseek.com/

### Backend
```bash
cd backend
python -m venv .venv
source .venv/bin/activate          # Windows: .venv\Scripts\activate
pip install -r requirements.txt
cp .env.example .env               # then edit .env with your keys
python seed.py                     # creates cadetai.db with sample data
uvicorn app.main:app --reload --port 8000
```
API now at http://localhost:8000  · Docs at http://localhost:8000/docs

### Frontend
```bash
cd frontend
npm install
cp .env.local.example .env.local   # NEXT_PUBLIC_API_URL=http://localhost:8000
npm run dev
```
App at http://localhost:3000

Sample login: `cadet@example.com` / `cadet1234`

---

## 3. Environment variables

`backend/.env`
```
SECRET_KEY=change-me-to-a-long-random-string
DATABASE_URL=sqlite:///./cadetai.db
GEMINI_API_KEY=your_gemini_key
DEEPSEEK_API_KEY=your_deepseek_key
CORS_ORIGINS=http://localhost:3000
RATE_LIMIT_PER_MINUTE=60
```

`frontend/.env.local`
```
NEXT_PUBLIC_API_URL=http://localhost:8000
```

---

## 4. Features map

| Feature              | Route (UI)         | Endpoint                       | AI provider |
|----------------------|--------------------|--------------------------------|-------------|
| Auth                 | /login /signup     | /auth/*                        | —           |
| Chat assistant       | /chat              | POST /chat (SSE stream)        | Gemini      |
| Notes analyzer       | /notes             | POST /upload-notes, /summary   | Gemini      |
| Quiz generator       | /quiz              | POST /generate-quiz            | DeepSeek    |
| Flashcards           | /flashcards        | POST /generate-flashcards      | DeepSeek    |
| Study planner        | /planner           | POST /generate-study-plan      | DeepSeek    |
| NDA mode             | /nda               | /nda/daily-quiz, /nda/ca, ...  | both        |
| Dashboard            | /dashboard         | GET /dashboard                 | —           |
| Analytics & weak topics | /analytics      | GET /analytics                 | DeepSeek    |

---

## 5. Deployment

See **DEPLOYMENT.md** — frontend → Vercel, backend → Render (or Fly.io / Railway).

To swap SQLite for Postgres, set `DATABASE_URL=postgresql+psycopg://user:pass@host/db` and `pip install psycopg[binary]`.

---

## 6. Security notes

- Passwords hashed with bcrypt
- JWT (HS256) in `Authorization: Bearer` header, 7-day expiry
- Pydantic input validation on every endpoint
- Simple per-IP rate limit (`RATE_LIMIT_PER_MINUTE`)
- API keys read from env only — never committed
- File uploads capped at 10 MB and restricted to `.pdf .txt .docx`

---

Built with discipline. **Jai Hind. 🇮🇳**
