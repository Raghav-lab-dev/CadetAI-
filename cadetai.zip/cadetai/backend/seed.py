"""Seed sample user + a note + sample analytics."""
from app.database import Base, engine, SessionLocal
from app.models import User, Note, AnalyticsEvent
from app.security import hash_password

Base.metadata.create_all(bind=engine)
db = SessionLocal()

if not db.query(User).filter(User.email == "cadet@example.com").first():
    u = User(
        email="cadet@example.com",
        name="Sample Cadet",
        password_hash=hash_password("cadet1234"),
        grade="NDA",
        language="en",
        streak=3,
    )
    db.add(u)
    db.commit()
    db.refresh(u)

    db.add(Note(
        user_id=u.id,
        title="Newton's Laws (sample)",
        filename="newton.txt",
        content=(
            "Newton's First Law: An object remains at rest or in uniform motion unless acted "
            "upon by a net external force. Second Law: F = ma. Third Law: For every action there "
            "is an equal and opposite reaction."
        ),
    ))
    db.add(AnalyticsEvent(user_id=u.id, kind="note_uploaded", value=1))
    db.commit()
    print("Seeded sample user: cadet@example.com / cadet1234")
else:
    print("Sample user already exists.")

db.close()
