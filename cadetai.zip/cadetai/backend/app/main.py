from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from .config import settings
from .database import Base, engine
from .utils.ratelimit import RateLimitMiddleware
from .routes import auth, chat, notes, quiz, flashcards, planner, nda, dashboard, analytics

Base.metadata.create_all(bind=engine)

app = FastAPI(title="CadetAI API", version="1.0.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.cors_list,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)
app.add_middleware(RateLimitMiddleware, limit_per_minute=settings.RATE_LIMIT_PER_MINUTE)

app.include_router(auth.router, prefix="/auth", tags=["auth"])
app.include_router(chat.router, tags=["chat"])
app.include_router(notes.router, tags=["notes"])
app.include_router(quiz.router, tags=["quiz"])
app.include_router(flashcards.router, tags=["flashcards"])
app.include_router(planner.router, tags=["planner"])
app.include_router(nda.router, prefix="/nda", tags=["nda"])
app.include_router(dashboard.router, tags=["dashboard"])
app.include_router(analytics.router, tags=["analytics"])


@app.get("/")
def health():
    return {"ok": True, "service": "CadetAI", "version": "1.0.0"}
