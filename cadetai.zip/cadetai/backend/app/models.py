from datetime import datetime
from sqlalchemy import Column, Integer, String, Text, DateTime, ForeignKey, Float, JSON, Boolean
from sqlalchemy.orm import relationship
from .database import Base


class User(Base):
    __tablename__ = "users"
    id = Column(Integer, primary_key=True)
    email = Column(String(255), unique=True, index=True, nullable=False)
    name = Column(String(120), nullable=False)
    password_hash = Column(String(255), nullable=False)
    grade = Column(String(20), nullable=True)        # e.g. "Class 10", "NDA"
    language = Column(String(8), default="en")       # en / hi
    streak = Column(Integer, default=0)
    last_active = Column(DateTime, default=datetime.utcnow)
    created_at = Column(DateTime, default=datetime.utcnow)

    notes = relationship("Note", back_populates="user", cascade="all,delete")
    quizzes = relationship("Quiz", back_populates="user", cascade="all,delete")
    flashcards = relationship("Flashcard", back_populates="user", cascade="all,delete")
    plans = relationship("StudyPlan", back_populates="user", cascade="all,delete")
    chats = relationship("ChatMessage", back_populates="user", cascade="all,delete")
    analytics = relationship("AnalyticsEvent", back_populates="user", cascade="all,delete")


class Note(Base):
    __tablename__ = "notes"
    id = Column(Integer, primary_key=True)
    user_id = Column(Integer, ForeignKey("users.id"))
    title = Column(String(255))
    filename = Column(String(255))
    content = Column(Text)                       # extracted text
    summary = Column(Text, nullable=True)
    key_points = Column(JSON, nullable=True)     # list[str]
    definitions = Column(JSON, nullable=True)    # list[{term,definition}]
    exam_tips = Column(JSON, nullable=True)      # list[str]
    created_at = Column(DateTime, default=datetime.utcnow)
    user = relationship("User", back_populates="notes")


class Quiz(Base):
    __tablename__ = "quizzes"
    id = Column(Integer, primary_key=True)
    user_id = Column(Integer, ForeignKey("users.id"))
    topic = Column(String(255))
    difficulty = Column(String(20))              # easy/medium/hard
    questions = Column(JSON)                     # list of {q,options,answer,explanation}
    score = Column(Float, nullable=True)
    answers = Column(JSON, nullable=True)        # user's chosen answers
    completed = Column(Boolean, default=False)
    created_at = Column(DateTime, default=datetime.utcnow)
    user = relationship("User", back_populates="quizzes")


class Flashcard(Base):
    __tablename__ = "flashcards"
    id = Column(Integer, primary_key=True)
    user_id = Column(Integer, ForeignKey("users.id"))
    deck = Column(String(255))
    front = Column(Text)
    back = Column(Text)
    last_reviewed = Column(DateTime, nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow)
    user = relationship("User", back_populates="flashcards")


class StudyPlan(Base):
    __tablename__ = "study_plans"
    id = Column(Integer, primary_key=True)
    user_id = Column(Integer, ForeignKey("users.id"))
    title = Column(String(255))
    goal = Column(Text)
    plan = Column(JSON)                          # list of {day, tasks:[...]}
    created_at = Column(DateTime, default=datetime.utcnow)
    user = relationship("User", back_populates="plans")


class ChatMessage(Base):
    __tablename__ = "chat_history"
    id = Column(Integer, primary_key=True)
    user_id = Column(Integer, ForeignKey("users.id"))
    conversation_id = Column(String(64), index=True)
    role = Column(String(16))                    # user / assistant
    content = Column(Text)
    created_at = Column(DateTime, default=datetime.utcnow)
    user = relationship("User", back_populates="chats")


class AnalyticsEvent(Base):
    __tablename__ = "analytics"
    id = Column(Integer, primary_key=True)
    user_id = Column(Integer, ForeignKey("users.id"))
    kind = Column(String(64))                    # study_minutes/quiz_taken/topic_completed
    topic = Column(String(255), nullable=True)
    value = Column(Float, default=0)
    meta = Column(JSON, nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow)
    user = relationship("User", back_populates="analytics")
