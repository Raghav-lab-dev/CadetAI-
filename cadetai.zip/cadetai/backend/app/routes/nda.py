from fastapi import APIRouter, Depends, Query
from sqlalchemy.orm import Session
from ..database import get_db
from ..deps import get_current_user
from ..models import User, Quiz, AnalyticsEvent
from ..ai import deepseek, gemini
from datetime import date

router = APIRouter()

NDA_SUBJECTS = ["Mathematics", "English", "General Knowledge", "Current Affairs", "SSB Interview"]


@router.get("/subjects")
def subjects():
    return NDA_SUBJECTS


@router.get("/daily-quiz")
async def daily_quiz(subject: str = Query("Mathematics"), user: User = Depends(get_current_user)):
    sys = "You build NDA-level MCQs. 5 questions. 4 options. answer index 0-3. include explanation."
    prompt = (
        f"Subject: {subject}\nDate: {date.today().isoformat()}\nLevel: NDA written exam\n"
        'Return JSON: {"questions":[{"q":"...","options":["a","b","c","d"],"answer":0,"explanation":"..."}]}'
    )
    obj = await deepseek.chat_json(sys, prompt)
    return {"subject": subject, "date": date.today().isoformat(), **obj}


@router.get("/current-affairs")
async def current_affairs(user: User = Depends(get_current_user)):
    text = await gemini.generate(
        "Give 8 important current-affairs bullets relevant to NDA aspirants for this week. "
        "Cover defence, polity, economy, sports, awards, science. Markdown bullets only.",
        system="You are an NDA current-affairs briefer. Be factual, concise, India-focused.",
    )
    return {"date": date.today().isoformat(), "markdown": text}


@router.get("/ssb-questions")
async def ssb(user: User = Depends(get_current_user)):
    sys = "You generate SSB Interview practice items (Personal Interview + Psychological tests)."
    prompt = (
        '5 mixed SSB practice items. Return JSON: {"items":[{"type":"PI|TAT|WAT|SRT","prompt":"...","tip":"..."}]}'
    )
    obj = await deepseek.chat_json(sys, prompt)
    return obj


@router.get("/practice-test")
async def practice(subject: str = "Mathematics", user: User = Depends(get_current_user)):
    sys = "You produce a 10-question NDA-level practice test."
    prompt = (
        f"Subject: {subject}\n"
        'Return JSON: {"questions":[{"q":"...","options":["a","b","c","d"],"answer":0,"explanation":"..."}]}'
    )
    obj = await deepseek.chat_json(sys, prompt)
    return {"subject": subject, **obj}
