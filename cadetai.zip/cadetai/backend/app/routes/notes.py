from fastapi import APIRouter, Depends, UploadFile, File, HTTPException
from sqlalchemy.orm import Session
from ..database import get_db
from ..deps import get_current_user
from ..models import Note, User, AnalyticsEvent
from ..schemas import SummaryIn
from ..utils.extract import extract_text
from ..ai import gemini
import json

router = APIRouter()


@router.post("/upload-notes")
async def upload_notes(file: UploadFile = File(...), db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    data = await file.read()
    try:
        text = extract_text(file.filename, data)
    except ValueError as e:
        raise HTTPException(400, str(e))
    note = Note(user_id=user.id, title=file.filename, filename=file.filename, content=text[:200_000])
    db.add(note)
    db.add(AnalyticsEvent(user_id=user.id, kind="note_uploaded", value=1, meta={"file": file.filename}))
    db.commit()
    db.refresh(note)
    return {"id": note.id, "title": note.title, "chars": len(note.content)}


@router.get("/notes")
def list_notes(db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    notes = db.query(Note).filter(Note.user_id == user.id).order_by(Note.id.desc()).all()
    return [{"id": n.id, "title": n.title, "created_at": n.created_at.isoformat(), "has_summary": bool(n.summary)} for n in notes]


@router.post("/generate-summary")
async def generate_summary(payload: SummaryIn, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    note = db.query(Note).filter(Note.id == payload.note_id, Note.user_id == user.id).first()
    if not note:
        raise HTTPException(404, "Note not found")

    prompt = (
        "Analyze the study notes below and respond in JSON with keys: "
        "summary (string, ~200 words), key_points (string[]), definitions ({term,definition}[]), "
        "exam_tips (string[]).\n\nNOTES:\n" + note.content[:30_000]
    )
    raw = await gemini.generate(
        prompt,
        system="You are an expert study coach. Output strict JSON only, no prose.",
    )
    # tolerate fences
    text = raw.strip().strip("`")
    if text.startswith("json"):
        text = text[4:]
    try:
        obj = json.loads(text)
    except Exception:
        obj = {"summary": raw, "key_points": [], "definitions": [], "exam_tips": []}

    note.summary = obj.get("summary")
    note.key_points = obj.get("key_points") or []
    note.definitions = obj.get("definitions") or []
    note.exam_tips = obj.get("exam_tips") or []
    db.commit()
    return obj


@router.get("/notes/{note_id}")
def get_note(note_id: int, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    note = db.query(Note).filter(Note.id == note_id, Note.user_id == user.id).first()
    if not note:
        raise HTTPException(404, "Not found")
    return {
        "id": note.id, "title": note.title, "content": note.content,
        "summary": note.summary, "key_points": note.key_points,
        "definitions": note.definitions, "exam_tips": note.exam_tips,
    }
