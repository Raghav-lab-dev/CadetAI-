from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from sqlalchemy import func
from ..database import get_db
from ..deps import get_current_user
from ..models import User, Quiz, AnalyticsEvent
from ..ai import deepseek

router = APIRouter()


@router.get("/analytics")
async def analytics(db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    by_topic = (
        db.query(Quiz.topic, func.avg(Quiz.score), func.count(Quiz.id))
        .filter(Quiz.user_id == user.id, Quiz.completed == True)
        .group_by(Quiz.topic)
        .all()
    )
    topics = [{"topic": t or "General", "avg": round(s or 0, 2), "count": c} for t, s, c in by_topic]
    weak = sorted([t for t in topics if t["avg"] < 60], key=lambda x: x["avg"])[:5]
    strong = sorted([t for t in topics if t["avg"] >= 75], key=lambda x: -x["avg"])[:5]

    recommendation = None
    if weak:
        sys = "You are a study coach. Suggest a focused revision plan."
        prompt = (
            "Learner's weak topics (with avg quiz score): "
            + ", ".join(f"{w['topic']} ({w['avg']}%)" for w in weak)
            + '\nReturn JSON: {"recommendation":"short paragraph","actions":["...","..."]}'
        )
        try:
            recommendation = await deepseek.chat_json(sys, prompt)
        except Exception:
            recommendation = {"recommendation": "Focus on weak topics with daily 20-min drills.", "actions": []}

    return {"topics": topics, "weak": weak, "strong": strong, "recommendation": recommendation}
