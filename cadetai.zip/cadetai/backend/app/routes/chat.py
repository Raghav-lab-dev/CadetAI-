import uuid
from fastapi import APIRouter, Depends
from fastapi.responses import StreamingResponse
from sqlalchemy.orm import Session
from ..database import get_db
from ..deps import get_current_user
from ..models import ChatMessage, User
from ..schemas import ChatIn
from ..ai import gemini

router = APIRouter()

SYSTEM = (
    "You are CadetAI, a disciplined and friendly study assistant for Indian students "
    "(Class 6–12) and NDA aspirants. Explain clearly with examples, support Hindi when asked, "
    "and use markdown with code blocks where useful."
)


@router.post("/chat")
async def chat(payload: ChatIn, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    convo = payload.conversation_id or str(uuid.uuid4())
    db.add(ChatMessage(user_id=user.id, conversation_id=convo, role="user", content=payload.message))
    db.commit()

    # Build short history for context
    history = (
        db.query(ChatMessage)
        .filter(ChatMessage.user_id == user.id, ChatMessage.conversation_id == convo)
        .order_by(ChatMessage.id.desc())
        .limit(20)
        .all()
    )
    history = list(reversed(history))
    transcript = "\n".join(f"{m.role.upper()}: {m.content}" for m in history)
    prompt = transcript + "\nASSISTANT:"

    async def event_stream():
        full = ""
        yield f"event: conversation\ndata: {convo}\n\n"
        try:
            async for chunk in gemini.stream(prompt, system=SYSTEM):
                full += chunk
                # SSE: escape newlines for safety
                safe = chunk.replace("\n", "\\n")
                yield f"data: {safe}\n\n"
        except Exception as e:
            yield f"event: error\ndata: {str(e)}\n\n"
        # persist assistant
        db.add(ChatMessage(user_id=user.id, conversation_id=convo, role="assistant", content=full))
        db.commit()
        yield "event: done\ndata: [DONE]\n\n"

    return StreamingResponse(event_stream(), media_type="text/event-stream")


@router.get("/chat/history/{conversation_id}")
def history(conversation_id: str, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    msgs = (
        db.query(ChatMessage)
        .filter(ChatMessage.user_id == user.id, ChatMessage.conversation_id == conversation_id)
        .order_by(ChatMessage.id.asc())
        .all()
    )
    return [{"role": m.role, "content": m.content, "at": m.created_at.isoformat()} for m in msgs]


@router.get("/chat/conversations")
def conversations(db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    rows = (
        db.query(ChatMessage.conversation_id)
        .filter(ChatMessage.user_id == user.id)
        .distinct()
        .all()
    )
    return [r[0] for r in rows]
