from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from sqlalchemy import func
from ..database import get_db
from ..deps import get_current_user
from ..models import User, Note, Quiz, Flashcard, StudyPlan, AnalyticsEvent
from datetime import datetime, timedelta

router = APIRouter()


@router.get("/dashboard")
def dashboard(db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    notes_total = db.query(func.count(Note.id)).filter(Note.user_id == user.id).scalar() or 0
    quiz_total = db.query(func.count(Quiz.id)).filter(Quiz.user_id == user.id, Quiz.completed == True).scalar() or 0
    cards_total = db.query(func.count(Flashcard.id)).filter(Flashcard.user_id == user.id).scalar() or 0
    plans_total = db.query(func.count(StudyPlan.id)).filter(StudyPlan.user_id == user.id).scalar() or 0
    avg_score = db.query(func.avg(Quiz.score)).filter(Quiz.user_id == user.id, Quiz.completed == True).scalar()

    # naive streak: count distinct days with any analytics event in last 30d
    since = datetime.utcnow() - timedelta(days=30)
    days = (
        db.query(func.date(AnalyticsEvent.created_at))
        .filter(AnalyticsEvent.user_id == user.id, AnalyticsEvent.created_at >= since)
        .distinct()
        .count()
    )

    return {
        "notes": notes_total,
        "quizzes": quiz_total,
        "flashcards": cards_total,
        "plans": plans_total,
        "avg_score": round(avg_score, 2) if avg_score else 0,
        "active_days_30d": days,
        "streak": user.streak,
    }
