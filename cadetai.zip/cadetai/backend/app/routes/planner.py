from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from ..database import get_db
from ..deps import get_current_user
from ..models import StudyPlan, User
from ..schemas import PlanIn
from ..ai import deepseek

router = APIRouter()


@router.post("/generate-study-plan")
async def generate(payload: PlanIn, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    sys = "You build realistic, friendly study schedules with daily tasks, revisions and breaks."
    prompt = (
        f"Goal: {payload.goal}\nDays: {payload.days}\nHours per day: {payload.hours_per_day}\n"
        f"Learner: {user.grade or 'student'}\n"
        'Return JSON: {"title":"...","plan":[{"day":1,"focus":"...","tasks":["...","..."],"revision":"..."}]}'
    )
    obj = await deepseek.chat_json(sys, prompt)
    plan = StudyPlan(user_id=user.id, title=obj.get("title", "Study Plan"), goal=payload.goal, plan=obj.get("plan", []))
    db.add(plan)
    db.commit()
    db.refresh(plan)
    return {"id": plan.id, "title": plan.title, "plan": plan.plan}


@router.get("/study-plans")
def list_plans(db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    rows = db.query(StudyPlan).filter(StudyPlan.user_id == user.id).order_by(StudyPlan.id.desc()).all()
    return [{"id": r.id, "title": r.title, "goal": r.goal, "plan": r.plan} for r in rows]
