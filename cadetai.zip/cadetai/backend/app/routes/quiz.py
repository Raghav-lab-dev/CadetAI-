from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from ..database import get_db
from ..deps import get_current_user
from ..models import Quiz, Note, User, AnalyticsEvent
from ..schemas import QuizIn, QuizSubmit
from ..ai import deepseek

router = APIRouter()


@router.post("/generate-quiz")
async def generate_quiz(payload: QuizIn, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    source = ""
    topic = payload.topic or "General"
    if payload.note_id:
        note = db.query(Note).filter(Note.id == payload.note_id, Note.user_id == user.id).first()
        if not note:
            raise HTTPException(404, "Note not found")
        source = note.content[:20_000]
        topic = note.title

    sys = (
        "You generate high-quality MCQs for Indian students. Each question must have exactly 4 options "
        "and an integer answer index (0-3) plus a brief explanation."
    )
    user_prompt = (
        f"Topic: {topic}\nDifficulty: {payload.difficulty}\nCount: {payload.count}\n"
        f"Source (optional):\n{source}\n\n"
        'Return JSON: {"questions":[{"q":"...","options":["a","b","c","d"],"answer":0,"explanation":"..."}]}'
    )
    obj = await deepseek.chat_json(sys, user_prompt)
    qs = obj.get("questions", [])[: payload.count]
    quiz = Quiz(user_id=user.id, topic=topic, difficulty=payload.difficulty, questions=qs)
    db.add(quiz)
    db.commit()
    db.refresh(quiz)
    # don't reveal answers on creation
    return {
        "id": quiz.id,
        "topic": quiz.topic,
        "difficulty": quiz.difficulty,
        "questions": [{"q": q["q"], "options": q["options"]} for q in qs],
    }


@router.post("/quiz/submit")
def submit_quiz(payload: QuizSubmit, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    quiz = db.query(Quiz).filter(Quiz.id == payload.quiz_id, Quiz.user_id == user.id).first()
    if not quiz:
        raise HTTPException(404, "Quiz not found")
    questions = quiz.questions or []
    correct = 0
    review = []
    for i, q in enumerate(questions):
        chosen = payload.answers[i] if i < len(payload.answers) else -1
        ok = chosen == q.get("answer")
        if ok:
            correct += 1
        review.append({
            "q": q["q"], "options": q["options"], "answer": q.get("answer"),
            "chosen": chosen, "ok": ok, "explanation": q.get("explanation", ""),
        })
    quiz.score = round(100 * correct / max(1, len(questions)), 2)
    quiz.answers = payload.answers
    quiz.completed = True
    db.add(AnalyticsEvent(user_id=user.id, kind="quiz_taken", topic=quiz.topic, value=quiz.score))
    db.commit()
    return {"score": quiz.score, "correct": correct, "total": len(questions), "review": review}


@router.get("/quizzes")
def list_quizzes(db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    qs = db.query(Quiz).filter(Quiz.user_id == user.id).order_by(Quiz.id.desc()).all()
    return [{"id": q.id, "topic": q.topic, "difficulty": q.difficulty, "score": q.score, "completed": q.completed} for q in qs]
