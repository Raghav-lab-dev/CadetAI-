from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from ..database import get_db
from ..deps import get_current_user
from ..models import Flashcard, Note, User
from ..schemas import FlashcardIn
from ..ai import deepseek

router = APIRouter()


@router.post("/generate-flashcards")
async def generate(payload: FlashcardIn, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    source = ""
    deck = payload.topic or "General"
    if payload.note_id:
        note = db.query(Note).filter(Note.id == payload.note_id, Note.user_id == user.id).first()
        if not note:
            raise HTTPException(404, "Note not found")
        source = note.content[:20_000]
        deck = note.title

    sys = "You make concise study flashcards. Front: question/term. Back: short answer."
    user_prompt = (
        f"Deck: {deck}\nCount: {payload.count}\nSource:\n{source}\n\n"
        'Return JSON: {"cards":[{"front":"...","back":"..."}]}'
    )
    obj = await deepseek.chat_json(sys, user_prompt)
    cards = obj.get("cards", [])[: payload.count]
    rows = [Flashcard(user_id=user.id, deck=deck, front=c["front"], back=c["back"]) for c in cards]
    db.add_all(rows)
    db.commit()
    return {"deck": deck, "count": len(rows)}


@router.get("/flashcards")
def list_cards(db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    rows = db.query(Flashcard).filter(Flashcard.user_id == user.id).order_by(Flashcard.id.desc()).all()
    return [{"id": r.id, "deck": r.deck, "front": r.front, "back": r.back} for r in rows]


@router.delete("/flashcards/{card_id}")
def delete_card(card_id: int, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    row = db.query(Flashcard).filter(Flashcard.id == card_id, Flashcard.user_id == user.id).first()
    if not row:
        raise HTTPException(404, "Not found")
    db.delete(row)
    db.commit()
    return {"ok": True}
