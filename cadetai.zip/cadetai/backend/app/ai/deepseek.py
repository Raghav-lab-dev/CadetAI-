"""DeepSeek client (OpenAI-compatible). Used for quizzes, flashcards, plans, analytics."""
import httpx
import json
from ..config import settings

BASE = "https://api.deepseek.com/v1"
MODEL = "deepseek-chat"


def _check():
    if not settings.DEEPSEEK_API_KEY:
        raise RuntimeError("DEEPSEEK_API_KEY is not set")


async def chat_json(system: str, user: str) -> dict:
    """Ask DeepSeek for strict JSON output."""
    _check()
    headers = {"Authorization": f"Bearer {settings.DEEPSEEK_API_KEY}"}
    body = {
        "model": MODEL,
        "messages": [
            {"role": "system", "content": system + "\nRespond with valid JSON only."},
            {"role": "user", "content": user},
        ],
        "response_format": {"type": "json_object"},
        "temperature": 0.4,
    }
    async with httpx.AsyncClient(timeout=90) as client:
        r = await client.post(f"{BASE}/chat/completions", json=body, headers=headers)
        r.raise_for_status()
        content = r.json()["choices"][0]["message"]["content"]
        try:
            return json.loads(content)
        except json.JSONDecodeError:
            # tolerate ```json fences
            content = content.strip().strip("`")
            if content.startswith("json"):
                content = content[4:]
            return json.loads(content)
