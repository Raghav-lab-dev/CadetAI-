"""Google Gemini client (REST). Used for chat, summaries, explanations."""
import httpx
import json
from typing import AsyncIterator
from ..config import settings

BASE = "https://generativelanguage.googleapis.com/v1beta"
MODEL = "gemini-1.5-flash"


def _check():
    if not settings.GEMINI_API_KEY:
        raise RuntimeError("GEMINI_API_KEY is not set")


async def generate(prompt: str, system: str | None = None) -> str:
    _check()
    url = f"{BASE}/models/{MODEL}:generateContent?key={settings.GEMINI_API_KEY}"
    body = {"contents": [{"parts": [{"text": prompt}]}]}
    if system:
        body["systemInstruction"] = {"parts": [{"text": system}]}
    async with httpx.AsyncClient(timeout=60) as client:
        r = await client.post(url, json=body)
        r.raise_for_status()
        data = r.json()
        try:
            return data["candidates"][0]["content"]["parts"][0]["text"]
        except (KeyError, IndexError):
            return ""


async def stream(prompt: str, system: str | None = None) -> AsyncIterator[str]:
    """Yields plain text chunks (SSE-friendly)."""
    _check()
    url = f"{BASE}/models/{MODEL}:streamGenerateContent?alt=sse&key={settings.GEMINI_API_KEY}"
    body = {"contents": [{"parts": [{"text": prompt}]}]}
    if system:
        body["systemInstruction"] = {"parts": [{"text": system}]}
    async with httpx.AsyncClient(timeout=None) as client:
        async with client.stream("POST", url, json=body) as r:
            r.raise_for_status()
            async for line in r.aiter_lines():
                if not line or not line.startswith("data:"):
                    continue
                payload = line[5:].strip()
                if payload == "[DONE]":
                    return
                try:
                    obj = json.loads(payload)
                    text = obj["candidates"][0]["content"]["parts"][0].get("text", "")
                    if text:
                        yield text
                except Exception:
                    continue
