from pydantic import BaseModel, EmailStr, Field
from typing import Any, Optional
from datetime import datetime


class UserCreate(BaseModel):
    email: EmailStr
    password: str = Field(min_length=8, max_length=128)
    name: str = Field(min_length=1, max_length=120)
    grade: Optional[str] = None
    language: Optional[str] = "en"


class UserLogin(BaseModel):
    email: EmailStr
    password: str


class UserOut(BaseModel):
    id: int
    email: EmailStr
    name: str
    grade: Optional[str]
    language: Optional[str]
    streak: int

    class Config:
        from_attributes = True


class TokenOut(BaseModel):
    access_token: str
    token_type: str = "bearer"
    user: UserOut


class ChatIn(BaseModel):
    conversation_id: Optional[str] = None
    message: str = Field(min_length=1, max_length=4000)


class SummaryIn(BaseModel):
    note_id: int


class QuizIn(BaseModel):
    note_id: Optional[int] = None
    topic: Optional[str] = Field(default=None, max_length=255)
    difficulty: str = Field(default="medium", pattern="^(easy|medium|hard)$")
    count: int = Field(default=5, ge=1, le=20)


class QuizSubmit(BaseModel):
    quiz_id: int
    answers: list[int]


class FlashcardIn(BaseModel):
    note_id: Optional[int] = None
    topic: Optional[str] = None
    count: int = Field(default=10, ge=1, le=30)


class PlanIn(BaseModel):
    goal: str = Field(min_length=3, max_length=500)
    days: int = Field(default=7, ge=1, le=60)
    hours_per_day: float = Field(default=2.0, ge=0.5, le=12)


class GenericOk(BaseModel):
    ok: bool = True
    data: Any = None
