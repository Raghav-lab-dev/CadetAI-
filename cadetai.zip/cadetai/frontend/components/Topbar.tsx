"use client";
import { useEffect, useState } from "react";
import { Moon, Sun, Languages } from "lucide-react";
import { useT } from "@/lib/i18n";

export default function Topbar({ title }: { title: string }) {
  const [dark, setDark] = useState(false);
  const { lang, setLanguage } = useT();
  useEffect(() => { setDark(document.documentElement.classList.contains("dark")); }, []);
  const toggle = () => {
    const next = !dark; setDark(next);
    document.documentElement.classList.toggle("dark", next);
    localStorage.setItem("theme", next ? "dark" : "light");
  };
  return (
    <header className="flex items-center justify-between px-6 py-4 border-b border-black/10 dark:border-white/10">
      <h1 className="font-display text-xl font-semibold">{title}</h1>
      <div className="flex items-center gap-2">
        <button className="btn-ghost" onClick={() => setLanguage(lang === "en" ? "hi" : "en")}>
          <Languages size={16}/> {lang.toUpperCase()}
        </button>
        <button className="btn-ghost" onClick={toggle}>
          {dark ? <Sun size={16}/> : <Moon size={16}/>}{dark ? "Light" : "Dark"}
        </button>
      </div>
    </header>
  );
}
