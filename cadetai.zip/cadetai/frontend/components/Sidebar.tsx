"use client";
import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import { LayoutDashboard, MessageSquare, FileText, ListChecks, Layers, CalendarDays, Shield, BarChart3, User as UserIcon, LogOut } from "lucide-react";
import { logout } from "@/lib/auth";

const items = [
  { href: "/dashboard", label: "Dashboard", icon: LayoutDashboard },
  { href: "/chat", label: "Chat", icon: MessageSquare },
  { href: "/notes", label: "Notes", icon: FileText },
  { href: "/quiz", label: "Quiz", icon: ListChecks },
  { href: "/flashcards", label: "Flashcards", icon: Layers },
  { href: "/planner", label: "Planner", icon: CalendarDays },
  { href: "/nda", label: "NDA Mode", icon: Shield },
  { href: "/analytics", label: "Analytics", icon: BarChart3 },
  { href: "/profile", label: "Profile", icon: UserIcon },
];

export default function Sidebar() {
  const path = usePathname();
  return (
    <aside className="w-60 shrink-0 border-r border-black/10 dark:border-white/10 p-4 hidden md:flex md:flex-col">
      <Link href="/dashboard" className="font-display text-2xl font-bold mb-6">🎖️ CadetAI</Link>
      <nav className="flex-1 space-y-1">
        {items.map(({ href, label, icon: Icon }) => {
          const active = path?.startsWith(href);
          return (
            <Link key={href} href={href}
              className={`flex items-center gap-3 px-3 py-2 rounded-xl text-sm ${active ? "bg-cadet-olive text-white" : "hover:bg-black/5 dark:hover:bg-white/10"}`}>
              <Icon size={18} /> {label}
            </Link>
          );
        })}
      </nav>
      <button onClick={logout} className="btn-ghost mt-4 justify-start"><LogOut size={16}/> Log out</button>
    </aside>
  );
}
