"use client";
import { useState } from "react";
import { Mic, MicOff } from "lucide-react";

export default function VoiceInput({ onText }: { onText: (s: string) => void }) {
  const [on, setOn] = useState(false);
  const start = () => {
    const SR: any = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    if (!SR) { alert("Voice input not supported in this browser"); return; }
    const rec = new SR();
    rec.lang = (localStorage.getItem("lang") || "en") === "hi" ? "hi-IN" : "en-IN";
    rec.interimResults = false;
    rec.onresult = (e: any) => onText(e.results[0][0].transcript);
    rec.onend = () => setOn(false);
    rec.start(); setOn(true);
  };
  return (
    <button type="button" onClick={start} className="btn-ghost" title="Voice input">
      {on ? <MicOff size={16}/> : <Mic size={16}/>}
    </button>
  );
}
