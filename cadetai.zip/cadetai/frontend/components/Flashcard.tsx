"use client";
import { useState } from "react";

export default function Flashcard({ front, back }: { front: string; back: string }) {
  const [flip, setFlip] = useState(false);
  return (
    <button onClick={() => setFlip(!flip)}
      className="card text-left w-full min-h-[160px] hover:border-cadet-gold transition">
      <div className="text-xs uppercase tracking-wide opacity-60 mb-2">{flip ? "Back" : "Front"}</div>
      <div className="text-lg">{flip ? back : front}</div>
    </button>
  );
}
