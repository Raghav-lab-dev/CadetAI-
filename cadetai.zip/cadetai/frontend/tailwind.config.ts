import type { Config } from "tailwindcss";

export default {
  darkMode: "class",
  content: ["./app/**/*.{ts,tsx}", "./components/**/*.{ts,tsx}"],
  theme: {
    extend: {
      colors: {
        cadet: {
          olive: "#4b5320",
          khaki: "#bdb76b",
          navy: "#1b2a41",
          gold: "#c9a227",
          steel: "#2c3e50",
        },
      },
      fontFamily: {
        display: ["ui-serif", "Georgia", "serif"],
      },
    },
  },
  plugins: [],
} satisfies Config;
