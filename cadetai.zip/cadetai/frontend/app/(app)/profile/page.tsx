"use client";
import { useEffect, useState } from "react";
import Topbar from "@/components/Topbar";
import { me, logout, type User } from "@/lib/auth";

export default function ProfilePage() {
  const [u, setU] = useState<User | null>(null);
  useEffect(() => { me().then(setU); }, []);
  return (
    <>
      <Topbar title="Profile"/>
      <div className="p-6 max-w-xl">
        <div className="card space-y-2">
          <div className="font-display text-2xl">{u?.name || "—"}</div>
          <div className="opacity-70">{u?.email}</div>
          <div>Grade: <b>{u?.grade || "—"}</b></div>
          <div>Streak: <b>🔥 {u?.streak ?? 0}</b></div>
          <button className="btn-ghost mt-3" onClick={logout}>Log out</button>
        </div>
      </div>
    </>
  );
}
