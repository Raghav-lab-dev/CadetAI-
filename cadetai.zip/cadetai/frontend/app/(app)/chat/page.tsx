"use client";
import { useEffect, useRef, useState } from "react";
import ReactMarkdown from "react-markdown";
import remarkGfm from "remark-gfm";
import { Copy, Send, Trash2, Volume2 } from "lucide-react";
import Topbar from "@/components/Topbar";
import VoiceInput from "@/components/VoiceInput";
import { API, getToken } from "@/lib/api";
import { speak } from "@/lib/tts";

type Msg = { role: "user" | "assistant"; content: string };

export default function ChatPage() {
  const [msgs, setMsgs] = useState<Msg[]>([]);
  const [input, setInput] = useState("");
  const [convo, setConvo] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const endRef = useRef<HTMLDivElement>(null);

  useEffect(() => { endRef.current?.scrollIntoView({ behavior: "smooth" }); }, [msgs]);

  const send = async () => {
    const text = input.trim(); if (!text || busy) return;
    setMsgs((m) => [...m, { role: "user", content: text }, { role: "assistant", content: "" }]);
    setInput(""); setBusy(true);
    try {
      const res = await fetch(`${API}/chat`, {
        method: "POST",
        headers: { "Content-Type": "application/json", Authorization: `Bearer ${getToken()}` },
        body: JSON.stringify({ message: text, conversation_id: convo }),
      });
      if (!res.body) throw new Error("No stream");
      const reader = res.body.getReader();
      const dec = new TextDecoder();
      let buf = "";
      while (true) {
        const { done, value } = await reader.read();
        if (done) break;
        buf += dec.decode(value, { stream: true });
        const parts = buf.split("\n\n"); buf = parts.pop() || "";
        for (const p of parts) {
          const lines = p.split("\n");
          const ev = lines.find(l => l.startsWith("event:"))?.slice(6).trim();
          const data = lines.filter(l => l.startsWith("data:")).map(l => l.slice(5).trim()).join("\n");
          if (ev === "conversation") setConvo(data);
          else if (ev === "done") {}
          else if (ev === "error") setMsgs((m) => { const c=[...m]; c[c.length-1] = { role:"assistant", content:"⚠️ "+data}; return c; });
          else if (data) setMsgs((m) => { const c=[...m]; c[c.length-1] = { role:"assistant", content: c[c.length-1].content + data.replace(/\\n/g, "\n") }; return c; });
        }
      }
    } catch (e:any) {
      setMsgs((m) => { const c=[...m]; c[c.length-1] = { role:"assistant", content:"⚠️ "+(e.message||"error") }; return c; });
    } finally { setBusy(false); }
  };

  return (
    <>
      <Topbar title="AI Chat Assistant" />
      <div className="flex flex-col h-[calc(100vh-64px)]">
        <div className="flex-1 overflow-y-auto p-6 space-y-4">
          {msgs.length === 0 && <div className="opacity-60 text-center mt-20">Ask anything — concepts, doubts, code, NDA prep…</div>}
          {msgs.map((m, i) => (
            <div key={i} className={`max-w-3xl ${m.role==="user" ? "ml-auto" : ""}`}>
              <div className={`card ${m.role==="user" ? "bg-cadet-olive text-white border-cadet-olive" : ""}`}>
                <div className="prose prose-sm dark:prose-invert max-w-none">
                  <ReactMarkdown remarkPlugins={[remarkGfm]}>{m.content || (m.role==="assistant" && busy ? "…" : "")}</ReactMarkdown>
                </div>
                {m.role === "assistant" && m.content && (
                  <div className="flex gap-2 mt-2">
                    <button className="btn-ghost text-xs" onClick={()=>navigator.clipboard.writeText(m.content)}><Copy size={14}/>Copy</button>
                    <button className="btn-ghost text-xs" onClick={()=>speak(m.content)}><Volume2 size={14}/>Speak</button>
                  </div>
                )}
              </div>
            </div>
          ))}
          <div ref={endRef}/>
        </div>
        <div className="border-t border-black/10 dark:border-white/10 p-4 flex gap-2">
          <button className="btn-ghost" onClick={()=>{setMsgs([]);setConvo(null);}}><Trash2 size={16}/>Clear</button>
          <VoiceInput onText={(s)=>setInput(s)}/>
          <input className="input flex-1" placeholder="Type your question…" value={input}
            onChange={(e)=>setInput(e.target.value)} onKeyDown={(e)=>e.key==="Enter" && send()}/>
          <button className="btn-gold" onClick={send} disabled={busy}><Send size={16}/>Send</button>
        </div>
      </div>
    </>
  );
}
