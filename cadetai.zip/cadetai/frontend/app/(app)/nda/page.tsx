"use client";
import { useEffect, useState } from "react";
import Topbar from "@/components/Topbar";
import ReactMarkdown from "react-markdown";
import remarkGfm from "remark-gfm";
import { api } from "@/lib/api";

const SUBJECTS = ["Mathematics", "English", "General Knowledge", "Current Affairs", "SSB Interview"];

export default function NdaPage() {
  const [tab, setTab] = useState<"quiz"|"ca"|"ssb"|"mock">("quiz");
  const [subject, setSubject] = useState("Mathematics");
  const [data, setData] = useState<any>(null); const [busy, setBusy] = useState(false);

  const load = async () => {
    setBusy(true); setData(null);
    try {
      if (tab==="quiz") setData(await api(`/nda/daily-quiz?subject=${encodeURIComponent(subject)}`));
      else if (tab==="ca") setData(await api(`/nda/current-affairs`));
      else if (tab==="ssb") setData(await api(`/nda/ssb-questions`));
      else setData(await api(`/nda/practice-test?subject=${encodeURIComponent(subject)}`));
    } finally { setBusy(false); }
  };

  useEffect(()=>{ load(); /* eslint-disable-next-line */ }, [tab, subject]);

  return (
    <>
      <Topbar title="NDA Mode 🛡️"/>
      <div className="p-6 space-y-4">
        <div className="flex flex-wrap gap-2">
          {[["quiz","Daily Quiz"],["ca","Current Affairs"],["ssb","SSB Practice"],["mock","Practice Test"]].map(([k,l])=>(
            <button key={k} onClick={()=>setTab(k as any)} className={`btn-ghost ${tab===k?"border-cadet-gold":""}`}>{l}</button>
          ))}
          {(tab==="quiz"||tab==="mock") && (
            <select className="input max-w-xs ml-auto" value={subject} onChange={(e)=>setSubject(e.target.value)}>
              {SUBJECTS.map(s=><option key={s}>{s}</option>)}
            </select>
          )}
        </div>
        {busy && <div className="opacity-60">Loading…</div>}
        {!busy && data && tab==="ca" && (
          <div className="card prose prose-sm dark:prose-invert max-w-none">
            <ReactMarkdown remarkPlugins={[remarkGfm]}>{data.markdown}</ReactMarkdown>
          </div>
        )}
        {!busy && data && (tab==="quiz"||tab==="mock") && (
          <div className="space-y-3">
            {data.questions?.map((q:any,i:number)=>(
              <details key={i} className="card">
                <summary className="cursor-pointer font-medium">Q{i+1}. {q.q}</summary>
                <ol className="mt-2 list-[upper-alpha] pl-5">{q.options.map((o:string,j:number)=><li key={j} className={j===q.answer?"text-cadet-gold font-medium":""}>{o}</li>)}</ol>
                <div className="text-sm opacity-80 mt-2"><b>Explanation:</b> {q.explanation}</div>
              </details>
            ))}
          </div>
        )}
        {!busy && data && tab==="ssb" && (
          <div className="grid sm:grid-cols-2 gap-3">
            {data.items?.map((it:any,i:number)=>(
              <div key={i} className="card">
                <div className="text-xs uppercase opacity-60">{it.type}</div>
                <div className="font-medium mt-1">{it.prompt}</div>
                {it.tip && <div className="text-sm opacity-80 mt-2">💡 {it.tip}</div>}
              </div>
            ))}
          </div>
        )}
      </div>
    </>
  );
}
