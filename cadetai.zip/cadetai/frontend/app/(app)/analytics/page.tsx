"use client";
import { useEffect, useState } from "react";
import Topbar from "@/components/Topbar";
import { api } from "@/lib/api";

export default function AnalyticsPage() {
  const [d, setD] = useState<any>(null);
  useEffect(() => { api("/analytics").then(setD).catch(()=>{}); }, []);
  if (!d) return (<><Topbar title="Analytics"/><div className="p-6 opacity-60">Loading…</div></>);

  return (
    <>
      <Topbar title="Performance Analytics"/>
      <div className="p-6 grid lg:grid-cols-2 gap-4">
        <div className="card">
          <div className="font-display text-lg mb-3">All topics</div>
          <ul className="space-y-2">
            {d.topics.map((t:any,i:number)=>(
              <li key={i} className="flex justify-between items-center">
                <span>{t.topic} <span className="opacity-60 text-xs">({t.count})</span></span>
                <span className="font-medium">{t.avg}%</span>
              </li>
            ))}
            {d.topics.length===0 && <li className="opacity-60">No quiz data yet.</li>}
          </ul>
        </div>
        <div className="card">
          <div className="font-display text-lg mb-2">⚠️ Weak topics</div>
          <ul className="space-y-1">{d.weak.map((t:any,i:number)=><li key={i}>{t.topic} — {t.avg}%</li>)}</ul>
          <div className="font-display text-lg mt-4 mb-2">💪 Strong topics</div>
          <ul className="space-y-1">{d.strong.map((t:any,i:number)=><li key={i}>{t.topic} — {t.avg}%</li>)}</ul>
        </div>
        {d.recommendation && (
          <div className="card lg:col-span-2">
            <div className="font-display text-lg mb-2">🎯 Recommendation</div>
            <p className="opacity-90">{d.recommendation.recommendation}</p>
            {d.recommendation.actions?.length>0 && (
              <ul className="list-disc pl-5 mt-2 space-y-1">{d.recommendation.actions.map((a:string,i:number)=><li key={i}>{a}</li>)}</ul>
            )}
          </div>
        )}
      </div>
    </>
  );
}
