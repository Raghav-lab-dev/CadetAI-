"use client";
import { useEffect, useState } from "react";
import Topbar from "@/components/Topbar";
import { api } from "@/lib/api";

export default function QuizPage() {
  const [notes, setNotes] = useState<any[]>([]);
  const [noteId, setNoteId] = useState<number | "">("");
  const [topic, setTopic] = useState("");
  const [difficulty, setDifficulty] = useState("medium");
  const [count, setCount] = useState(5);
  const [quiz, setQuiz] = useState<any | null>(null);
  const [answers, setAnswers] = useState<number[]>([]);
  const [result, setResult] = useState<any | null>(null);
  const [busy, setBusy] = useState(false);

  useEffect(() => { api("/notes").then(setNotes); }, []);

  const generate = async () => {
    setBusy(true); setResult(null);
    try {
      const q = await api("/generate-quiz", {
        method: "POST",
        body: JSON.stringify({ note_id: noteId || null, topic: topic || null, difficulty, count }),
      });
      setQuiz(q); setAnswers(new Array(q.questions.length).fill(-1));
    } finally { setBusy(false); }
  };

  const submit = async () => {
    if (!quiz) return;
    const r = await api("/quiz/submit", { method: "POST", body: JSON.stringify({ quiz_id: quiz.id, answers }) });
    setResult(r);
  };

  return (
    <>
      <Topbar title="Quiz Generator"/>
      <div className="p-6 max-w-3xl mx-auto space-y-4">
        <div className="card grid sm:grid-cols-2 gap-3">
          <div><label className="label">From note (optional)</label>
            <select className="input" value={noteId} onChange={(e)=>setNoteId(e.target.value ? Number(e.target.value) : "")}>
              <option value="">— None —</option>
              {notes.map(n => <option key={n.id} value={n.id}>{n.title}</option>)}
            </select></div>
          <div><label className="label">Topic</label><input className="input" value={topic} onChange={(e)=>setTopic(e.target.value)} placeholder="e.g. Trigonometry"/></div>
          <div><label className="label">Difficulty</label>
            <select className="input" value={difficulty} onChange={(e)=>setDifficulty(e.target.value)}>
              {["easy","medium","hard"].map(d=><option key={d}>{d}</option>)}
            </select></div>
          <div><label className="label">Number of questions</label><input className="input" type="number" min={1} max={20} value={count} onChange={(e)=>setCount(Number(e.target.value))}/></div>
          <div className="sm:col-span-2"><button className="btn-gold" onClick={generate} disabled={busy}>{busy ? "Generating…" : "Generate quiz"}</button></div>
        </div>

        {quiz && !result && (
          <div className="space-y-3">
            {quiz.questions.map((q:any, i:number) => (
              <div key={i} className="card">
                <div className="font-medium mb-2">Q{i+1}. {q.q}</div>
                <div className="grid gap-2">
                  {q.options.map((o:string, j:number) => (
                    <label key={j} className={`btn-ghost justify-start ${answers[i]===j?"border-cadet-gold":""}`}>
                      <input type="radio" hidden checked={answers[i]===j} onChange={()=>{const a=[...answers]; a[i]=j; setAnswers(a);}}/>
                      {String.fromCharCode(65+j)}. {o}
                    </label>
                  ))}
                </div>
              </div>
            ))}
            <button className="btn-primary" onClick={submit}>Submit answers</button>
          </div>
        )}

        {result && (
          <div className="space-y-3">
            <div className="card"><div className="font-display text-2xl">Score: {result.score}% ({result.correct}/{result.total})</div></div>
            {result.review.map((r:any, i:number) => (
              <div key={i} className={`card ${r.ok ? "border-green-500/40" : "border-red-500/40"}`}>
                <div className="font-medium">{r.ok ? "✓" : "✗"} Q{i+1}. {r.q}</div>
                <div className="text-sm opacity-80 mt-1">Correct: {r.options[r.answer]}</div>
                <div className="text-sm opacity-80">Your answer: {r.chosen>=0 ? r.options[r.chosen] : "—"}</div>
                {r.explanation && <div className="text-sm mt-2 opacity-90"><b>Explanation:</b> {r.explanation}</div>}
              </div>
            ))}
          </div>
        )}
      </div>
    </>
  );
}
