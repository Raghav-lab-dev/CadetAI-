"use client";
import { useEffect, useState } from "react";
import Topbar from "@/components/Topbar";
import { api, apiUpload } from "@/lib/api";
import jsPDF from "jspdf";

export default function NotesPage() {
  const [notes, setNotes] = useState<any[]>([]);
  const [active, setActive] = useState<any | null>(null);
  const [busy, setBusy] = useState(false);
  const [q, setQ] = useState("");

  const reload = () => api("/notes").then(setNotes);
  useEffect(() => { reload(); }, []);

  const upload = async (f: File) => {
    setBusy(true);
    try { await apiUpload("/upload-notes", f); await reload(); }
    finally { setBusy(false); }
  };

  const summarize = async (id: number) => {
    setBusy(true);
    try { await api("/generate-summary", { method: "POST", body: JSON.stringify({ note_id: id }) }); await open(id); }
    finally { setBusy(false); }
  };

  const open = async (id: number) => setActive(await api(`/notes/${id}`));

  const exportPdf = () => {
    if (!active) return;
    const doc = new jsPDF();
    doc.setFontSize(16); doc.text(active.title || "Note", 10, 15);
    doc.setFontSize(11);
    const txt = `Summary:\n${active.summary || ""}\n\nKey points:\n- ${(active.key_points||[]).join("\n- ")}`;
    const lines = doc.splitTextToSize(txt, 180);
    doc.text(lines, 10, 25);
    doc.save(`${active.title || "note"}.pdf`);
  };

  const filtered = notes.filter(n => n.title.toLowerCase().includes(q.toLowerCase()));

  return (
    <>
      <Topbar title="Notes Analyzer" />
      <div className="p-6 grid lg:grid-cols-[320px_1fr] gap-6">
        <div className="space-y-3">
          <label className="card block cursor-pointer text-center">
            <div className="font-display">📎 Upload PDF / DOCX / TXT</div>
            <input type="file" accept=".pdf,.docx,.txt" hidden onChange={(e)=>{const f=e.target.files?.[0]; if(f) upload(f);}}/>
            <div className="text-xs opacity-60 mt-1">Max 10 MB</div>
          </label>
          <input className="input" placeholder="🔍 Search notes…" value={q} onChange={(e)=>setQ(e.target.value)}/>
          <div className="space-y-2">
            {filtered.map(n => (
              <button key={n.id} onClick={()=>open(n.id)} className={`card w-full text-left ${active?.id===n.id?"border-cadet-gold":""}`}>
                <div className="font-medium truncate">{n.title}</div>
                <div className="text-xs opacity-60">{n.has_summary ? "✓ summary" : "no summary yet"}</div>
              </button>
            ))}
            {filtered.length === 0 && <div className="text-sm opacity-60">No notes yet.</div>}
          </div>
        </div>

        <div>
          {!active && <div className="card opacity-70">Select a note to view or generate summary.</div>}
          {active && (
            <div className="space-y-4">
              <div className="flex items-center gap-2">
                <h2 className="h-title flex-1 truncate">{active.title}</h2>
                <button className="btn-primary" disabled={busy} onClick={()=>summarize(active.id)}>{busy ? "…" : "Generate / Refresh"}</button>
                <button className="btn-ghost" onClick={exportPdf}>Export PDF</button>
              </div>
              {active.summary && <div className="card"><div className="font-display text-lg mb-2">Summary</div><p className="opacity-90 whitespace-pre-wrap">{active.summary}</p></div>}
              {active.key_points?.length>0 && <div className="card"><div className="font-display text-lg mb-2">Key points</div><ul className="list-disc pl-5 space-y-1">{active.key_points.map((k:string,i:number)=><li key={i}>{k}</li>)}</ul></div>}
              {active.definitions?.length>0 && <div className="card"><div className="font-display text-lg mb-2">Definitions</div><ul className="space-y-2">{active.definitions.map((d:any,i:number)=><li key={i}><b>{d.term}</b> — {d.definition}</li>)}</ul></div>}
              {active.exam_tips?.length>0 && <div className="card"><div className="font-display text-lg mb-2">Exam tips</div><ul className="list-disc pl-5 space-y-1">{active.exam_tips.map((t:string,i:number)=><li key={i}>{t}</li>)}</ul></div>}
            </div>
          )}
        </div>
      </div>
    </>
  );
}
