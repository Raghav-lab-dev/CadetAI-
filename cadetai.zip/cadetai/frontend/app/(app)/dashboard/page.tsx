"use client";
import { useEffect, useState } from "react";
import Topbar from "@/components/Topbar";
import { api } from "@/lib/api";

export default function DashboardPage() {
  const [d, setD] = useState<any>(null);
  useEffect(() => { api("/dashboard").then(setD).catch(()=>{}); }, []);
  const Stat = ({ label, value }: any) => (
    <div className="card"><div className="text-sm opacity-70">{label}</div><div className="text-3xl font-display mt-1">{value ?? "—"}</div></div>
  );
  return (
    <>
      <Topbar title="Dashboard" />
      <section className="p-6 grid sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <Stat label="Notes uploaded" value={d?.notes}/>
        <Stat label="Quizzes attempted" value={d?.quizzes}/>
        <Stat label="Average score" value={d?.avg_score != null ? `${d.avg_score}%` : "—"}/>
        <Stat label="Flashcards" value={d?.flashcards}/>
        <Stat label="Study plans" value={d?.plans}/>
        <Stat label="Active days (30d)" value={d?.active_days_30d}/>
        <Stat label="🔥 Streak" value={d?.streak}/>
      </section>
      <section className="px-6 pb-10">
        <div className="card">
          <div className="font-display text-xl">Welcome, Cadet.</div>
          <p className="opacity-80 mt-1">Pick a mission from the sidebar — upload notes, run a quiz, or jump into NDA mode.</p>
        </div>
      </section>
    </>
  );
}
