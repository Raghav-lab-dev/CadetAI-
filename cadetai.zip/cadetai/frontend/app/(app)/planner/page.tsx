"use client";
import { useEffect, useState } from "react";
import Topbar from "@/components/Topbar";
import { api } from "@/lib/api";

export default function PlannerPage() {
  const [plans, setPlans] = useState<any[]>([]);
  const [goal, setGoal] = useState(""); const [days, setDays] = useState(7); const [hours, setHours] = useState(2);
  const [busy, setBusy] = useState(false);
  const reload = () => api("/study-plans").then(setPlans);
  useEffect(() => { reload(); }, []);

  const generate = async () => {
    if (!goal.trim()) return;
    setBusy(true);
    try { await api("/generate-study-plan", { method:"POST", body: JSON.stringify({ goal, days, hours_per_day: hours }) }); await reload(); }
    finally { setBusy(false); }
  };

  return (
    <>
      <Topbar title="Study Planner"/>
      <div className="p-6 space-y-6">
        <div className="card grid sm:grid-cols-4 gap-3">
          <input className="input sm:col-span-2" placeholder="Goal (e.g. Finish Class 10 Physics in 14 days)" value={goal} onChange={(e)=>setGoal(e.target.value)}/>
          <input className="input" type="number" min={1} max={60} value={days} onChange={(e)=>setDays(Number(e.target.value))}/>
          <input className="input" type="number" min={0.5} step={0.5} max={12} value={hours} onChange={(e)=>setHours(Number(e.target.value))}/>
          <button className="btn-gold sm:col-span-4" onClick={generate} disabled={busy}>{busy?"Building plan…":"Generate plan"}</button>
        </div>

        {plans.map(p => (
          <div key={p.id} className="card">
            <div className="font-display text-xl mb-1">{p.title}</div>
            <div className="text-sm opacity-70 mb-3">Goal: {p.goal}</div>
            <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-3">
              {(p.plan||[]).map((d:any, i:number)=>(
                <div key={i} className="rounded-xl border border-black/10 dark:border-white/10 p-3">
                  <div className="font-semibold">Day {d.day} — {d.focus}</div>
                  <ul className="list-disc pl-5 mt-1 text-sm space-y-1">{(d.tasks||[]).map((t:string,j:number)=><li key={j}>{t}</li>)}</ul>
                  {d.revision && <div className="text-xs opacity-70 mt-2">Revise: {d.revision}</div>}
                </div>
              ))}
            </div>
          </div>
        ))}
        {plans.length===0 && <div className="opacity-60">No plans yet.</div>}
      </div>
    </>
  );
}
