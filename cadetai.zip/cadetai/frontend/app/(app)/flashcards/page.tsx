"use client";
import { useEffect, useState } from "react";
import Topbar from "@/components/Topbar";
import { api } from "@/lib/api";
import Flashcard from "@/components/Flashcard";

export default function FlashcardsPage() {
  const [notes, setNotes] = useState<any[]>([]);
  const [cards, setCards] = useState<any[]>([]);
  const [noteId, setNoteId] = useState<number | "">("");
  const [topic, setTopic] = useState(""); const [count, setCount] = useState(10);
  const [busy, setBusy] = useState(false); const [q, setQ] = useState("");

  const reload = () => api("/flashcards").then(setCards);
  useEffect(() => { api("/notes").then(setNotes); reload(); }, []);

  const generate = async () => {
    setBusy(true);
    try { await api("/generate-flashcards", { method:"POST", body: JSON.stringify({ note_id: noteId||null, topic: topic||null, count }) }); await reload(); }
    finally { setBusy(false); }
  };

  const exportTxt = () => {
    const blob = new Blob([cards.map(c=>`Q: ${c.front}\nA: ${c.back}\n`).join("\n")], {type:"text/plain"});
    const url = URL.createObjectURL(blob); const a=document.createElement("a"); a.href=url; a.download="flashcards.txt"; a.click();
  };

  const filtered = cards.filter(c => (c.front+c.back+c.deck).toLowerCase().includes(q.toLowerCase()));

  return (
    <>
      <Topbar title="Flashcards"/>
      <div className="p-6 space-y-6">
        <div className="card grid sm:grid-cols-4 gap-3">
          <select className="input" value={noteId} onChange={(e)=>setNoteId(e.target.value?Number(e.target.value):"")}>
            <option value="">From note (optional)</option>
            {notes.map(n=><option key={n.id} value={n.id}>{n.title}</option>)}
          </select>
          <input className="input" placeholder="Topic" value={topic} onChange={(e)=>setTopic(e.target.value)}/>
          <input className="input" type="number" min={1} max={30} value={count} onChange={(e)=>setCount(Number(e.target.value))}/>
          <button className="btn-gold" onClick={generate} disabled={busy}>{busy?"…":"Generate"}</button>
        </div>
        <div className="flex gap-2">
          <input className="input" placeholder="🔍 Search" value={q} onChange={(e)=>setQ(e.target.value)}/>
          <button className="btn-ghost" onClick={exportTxt}>Export</button>
        </div>
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {filtered.map(c => <Flashcard key={c.id} front={c.front} back={c.back}/>)}
        </div>
        {filtered.length===0 && <div className="opacity-60">No flashcards yet.</div>}
      </div>
    </>
  );
}
