import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "CadetAI — Discipline. Study. Excel.",
  description: "AI-powered study assistant for Classes 6–12 and NDA aspirants.",
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en" suppressHydrationWarning>
      <head>
        <script
          dangerouslySetInnerHTML={{
            __html: `try{const t=localStorage.getItem('theme');if(t==='dark'||(!t&&matchMedia('(prefers-color-scheme:dark)').matches))document.documentElement.classList.add('dark');}catch(e){}`,
          }}
        />
      </head>
      <body>{children}</body>
    </html>
  );
}
