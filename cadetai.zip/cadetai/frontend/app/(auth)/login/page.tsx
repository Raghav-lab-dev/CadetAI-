"use client";
import { useState } from "react";
import { useRouter } from "next/navigation";
import Link from "next/link";
import { login } from "@/lib/auth";

export default function LoginPage() {
  const router = useRouter();
  const [email, setEmail] = useState("cadet@example.com");
  const [password, setPassword] = useState("cadet1234");
  const [err, setErr] = useState("");
  const [loading, setLoading] = useState(false);

  const submit = async (e: React.FormEvent) => {
    e.preventDefault(); setLoading(true); setErr("");
    try { await login(email, password); router.push("/dashboard"); }
    catch (e: any) { setErr(e.message || "Login failed"); }
    finally { setLoading(false); }
  };

  return (
    <main className="min-h-screen grid place-items-center px-4">
      <form onSubmit={submit} className="card w-full max-w-md space-y-4">
        <div className="font-display text-3xl">🎖️ Welcome back, Cadet</div>
        <div><label className="label">Email</label>
          <input className="input" type="email" value={email} onChange={(e)=>setEmail(e.target.value)} required/></div>
        <div><label className="label">Password</label>
          <input className="input" type="password" value={password} onChange={(e)=>setPassword(e.target.value)} required minLength={8}/></div>
        {err && <div className="text-sm text-red-500">{err}</div>}
        <button className="btn-gold w-full justify-center" disabled={loading}>{loading ? "..." : "Log in"}</button>
        <div className="text-sm opacity-70 text-center">No account? <Link className="underline" href="/signup">Sign up</Link></div>
      </form>
    </main>
  );
}
