"use client";
import { useState } from "react";
import { useRouter } from "next/navigation";
import Link from "next/link";
import { signup } from "@/lib/auth";

export default function SignupPage() {
  const router = useRouter();
  const [form, setForm] = useState({ name: "", email: "", password: "", grade: "Class 10" });
  const [err, setErr] = useState(""); const [loading, setLoading] = useState(false);
  const set = (k: string) => (e: any) => setForm({ ...form, [k]: e.target.value });

  const submit = async (e: React.FormEvent) => {
    e.preventDefault(); setLoading(true); setErr("");
    try { await signup(form); router.push("/dashboard"); }
    catch (e: any) { setErr(e.message || "Signup failed"); }
    finally { setLoading(false); }
  };

  return (
    <main className="min-h-screen grid place-items-center px-4">
      <form onSubmit={submit} className="card w-full max-w-md space-y-4">
        <div className="font-display text-3xl">🎖️ Enlist with CadetAI</div>
        <div><label className="label">Full name</label><input className="input" value={form.name} onChange={set("name")} required/></div>
        <div><label className="label">Email</label><input className="input" type="email" value={form.email} onChange={set("email")} required/></div>
        <div><label className="label">Password (min 8)</label><input className="input" type="password" value={form.password} onChange={set("password")} required minLength={8}/></div>
        <div><label className="label">Grade / Track</label>
          <select className="input" value={form.grade} onChange={set("grade")}>
            {["Class 6","Class 7","Class 8","Class 9","Class 10","Class 11","Class 12","NDA"].map(g => <option key={g}>{g}</option>)}
          </select>
        </div>
        {err && <div className="text-sm text-red-500">{err}</div>}
        <button className="btn-gold w-full justify-center" disabled={loading}>{loading ? "..." : "Create account"}</button>
        <div className="text-sm opacity-70 text-center">Have an account? <Link className="underline" href="/login">Log in</Link></div>
      </form>
    </main>
  );
}
