import Link from "next/link";

export default function Landing() {
  return (
    <main className="min-h-screen">
      <header className="flex items-center justify-between px-8 py-5">
        <div className="font-display text-2xl font-bold">🎖️ CadetAI</div>
        <nav className="flex gap-3">
          <Link href="/login" className="btn-ghost">Log in</Link>
          <Link href="/signup" className="btn-gold">Get started</Link>
        </nav>
      </header>

      <section className="px-8 py-20 max-w-5xl mx-auto text-center">
        <h1 className="font-display text-5xl md:text-6xl font-bold leading-tight">
          Discipline. Study. <span className="text-cadet-gold">Excel.</span>
        </h1>
        <p className="mt-6 text-lg opacity-80 max-w-2xl mx-auto">
          The AI-powered study assistant built for Indian school students (Classes 6–12) and NDA aspirants.
          Smart summaries, quizzes, flashcards, plans — and a dedicated NDA mode.
        </p>
        <div className="mt-8 flex gap-3 justify-center">
          <Link href="/signup" className="btn-gold">Start free</Link>
          <Link href="/login" className="btn-ghost">I already have an account</Link>
        </div>
      </section>

      <section className="px-8 pb-20 grid md:grid-cols-3 gap-5 max-w-6xl mx-auto">
        {[
          ["AI Chat & Doubts", "Ask anything. Gemini explains step-by-step with code & markdown."],
          ["Notes → Summary", "Upload PDF/DOCX/TXT. Get summary, key points, definitions, exam tips."],
          ["Quizzes & Flashcards", "Auto-generated MCQs and flashcards by topic and difficulty."],
          ["Study Planner", "Personalized daily & weekly plans with revision reminders."],
          ["NDA Mode", "Daily quiz, current affairs, SSB practice across 5 subjects."],
          ["Analytics", "Streaks, weak topics, recommended drills."],
        ].map(([t, d]) => (
          <div key={t} className="card">
            <div className="font-display text-xl">{t}</div>
            <p className="mt-2 text-sm opacity-80">{d}</p>
          </div>
        ))}
      </section>

      <footer className="text-center text-sm opacity-60 py-8">Jai Hind. 🇮🇳</footer>
    </main>
  );
}
