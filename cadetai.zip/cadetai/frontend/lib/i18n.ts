"use client";
import { useState } from "react";

const dict: Record<string, Record<string, string>> = {
  en: { dashboard: "Dashboard", chat: "Chat", notes: "Notes", quiz: "Quiz", flashcards: "Flashcards", planner: "Planner", nda: "NDA Mode", analytics: "Analytics", profile: "Profile", logout: "Log out" },
  hi: { dashboard: "डैशबोर्ड", chat: "चैट", notes: "नोट्स", quiz: "क्विज़", flashcards: "फ्लैशकार्ड", planner: "योजना", nda: "एनडीए मोड", analytics: "विश्लेषण", profile: "प्रोफ़ाइल", logout: "लॉग आउट" },
};

export function useT() {
  const [lang, setLang] = useState<"en" | "hi">(typeof window !== "undefined" ? ((localStorage.getItem("lang") as any) || "en") : "en");
  const setLanguage = (l: "en" | "hi") => { setLang(l); localStorage.setItem("lang", l); };
  return { t: (k: string) => dict[lang][k] || k, lang, setLanguage };
}
