export const API = process.env.NEXT_PUBLIC_API_URL || "http://localhost:8000";

export function getToken(): string | null {
  if (typeof window === "undefined") return null;
  return localStorage.getItem("cadet_token");
}
export function setToken(t: string) { localStorage.setItem("cadet_token", t); }
export function clearToken() { localStorage.removeItem("cadet_token"); }

export async function api<T = any>(path: string, opts: RequestInit = {}): Promise<T> {
  const headers: Record<string, string> = { "Content-Type": "application/json", ...(opts.headers as any) };
  const t = getToken();
  if (t) headers["Authorization"] = `Bearer ${t}`;
  const res = await fetch(`${API}${path}`, { ...opts, headers });
  if (!res.ok) {
    const msg = await res.text().catch(() => res.statusText);
    throw new Error(msg || `HTTP ${res.status}`);
  }
  const ct = res.headers.get("content-type") || "";
  return ct.includes("application/json") ? res.json() : (res.text() as any);
}

export async function apiUpload<T = any>(path: string, file: File): Promise<T> {
  const fd = new FormData();
  fd.append("file", file);
  const t = getToken();
  const res = await fetch(`${API}${path}`, {
    method: "POST", body: fd,
    headers: t ? { Authorization: `Bearer ${t}` } : undefined,
  });
  if (!res.ok) throw new Error(await res.text());
  return res.json();
}
