"use client";
import { api, setToken, clearToken, getToken } from "./api";

export type User = { id: number; email: string; name: string; grade?: string; language?: string; streak: number };

export async function login(email: string, password: string) {
  const r = await api<{ access_token: string; user: User }>("/auth/login", {
    method: "POST", body: JSON.stringify({ email, password }),
  });
  setToken(r.access_token);
  return r.user;
}

export async function signup(payload: { email: string; password: string; name: string; grade?: string }) {
  const r = await api<{ access_token: string; user: User }>("/auth/signup", {
    method: "POST", body: JSON.stringify({ ...payload, language: "en" }),
  });
  setToken(r.access_token);
  return r.user;
}

export async function me(): Promise<User | null> {
  if (!getToken()) return null;
  try { return await api<User>("/auth/me"); } catch { clearToken(); return null; }
}

export function logout() { clearToken(); location.href = "/login"; }
