# Deployment Guide

## Frontend → Vercel

1. Push the repo to GitHub.
2. On vercel.com → "New Project" → import the repo.
3. Set **Root Directory** to `frontend`.
4. Framework preset: **Next.js** (auto-detected).
5. Add env var: `NEXT_PUBLIC_API_URL=https://your-backend.onrender.com`
6. Deploy.

## Backend → Render

1. On render.com → "New +" → "Web Service" → connect repo.
2. **Root Directory:** `backend`
3. **Runtime:** Python 3
4. **Build command:** `pip install -r requirements.txt`
5. **Start command:** `uvicorn app.main:app --host 0.0.0.0 --port $PORT`
6. Add env vars from `backend/.env.example` (set real keys for `GEMINI_API_KEY`, `DEEPSEEK_API_KEY`, `SECRET_KEY`).
7. Set `CORS_ORIGINS=https://your-frontend.vercel.app`
8. (Optional) attach a Render Postgres instance and set `DATABASE_URL` to the Internal URL.

## Docker (local all-in-one)

```bash
docker compose up --build
```
Frontend on :3000, backend on :8000.

## Upgrading SQLite → Postgres

```bash
pip install "psycopg[binary]"
export DATABASE_URL=postgresql+psycopg://user:pass@host:5432/cadetai
python -c "from app.database import Base, engine; Base.metadata.create_all(engine)"
```
